'''
Created on Jun 21, 2011

@author: mariano
'''
from multineuro.vector2d import V2d
def scale(pos, factor):

    return (V2d(pos) * V2d(factor)).ipos
